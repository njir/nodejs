// config/database.js
module.exports = {
	connectionLimit: 150,
	host: '127.0.0.1',
	port: 3306,
	user: 'root',
	password: '1234',
	database: 'test',
	debug: false,
	charset: 'UTF8_GENERAL_CI'
};
