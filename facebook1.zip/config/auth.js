// config/auth.js
module.exports = {
	facebookAuth : {
		clientID: 'clientID',
		clientSecret: 'clientSecret',
		callbackURL: "http://localhost/auth/facebook/callback"
	}
};
