node-InAppBilling
=================

Android Google Play In-app Billing verification lib

Google Play publickey input the below file.

file: 'lib/verifier.js'
line number 3 : ,publicKeyString = '------------- your public key here --------------'



reference documentation - http://developer.android.com/google/play/billing/billing_overview.html

reference source - https://github.com/mgoldsborough/google-play-in-app-billing-verification